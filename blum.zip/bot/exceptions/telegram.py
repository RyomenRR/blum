
class TelegramInvalidSessionException(Exception):
    pass

class TelegramProxyError(Exception):
    pass